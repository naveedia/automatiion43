import { getAllSlugs, getPostBySlug } from "../../../lib/posts";
import { notFound } from "next/navigation";

export const revalidate = 0;

export async function generateStaticParams() {
  return getAllSlugs().map((slug) => ({ slug }));
}

export async function generateMetadata({ params }) {
  try {
    const post = getPostBySlug(params.slug);
    return { title: post.title, description: post.dek };
  } catch {
    return {};
  }
}

function formatStamp(dispatch, date) {
  const d = new Date(date).toISOString().slice(0, 10).replace(/-/g, ".");
  return `Dispatch №${String(dispatch).padStart(3, "0")} — ${d}`;
}

export default function PostPage({ params }) {
  let post;
  try {
    post = getPostBySlug(params.slug);
  } catch {
    notFound();
  }

  return (
    <main className="wrap post-wrap">
      <div className="dispatch-stamp">{formatStamp(post.dispatch, post.date)}</div>
      <h1 className="post-title">{post.title}</h1>
      <p className="post-dek">{post.dek}</p>
      <div className="post-body" dangerouslySetInnerHTML={{ __html: post.html }} />
      <a href="/" className="back-link">&larr; All dispatches</a>
    </main>
  );
}

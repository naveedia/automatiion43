import { generatePost } from "../../../../lib/generate";
import { getFile, putFile } from "../../../../lib/github";
import siteConfig from "../../../../site.config";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

function slugify(str) {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function isAuthorized(req) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return true; // no secret configured — open (fine for manual testing only)
  const auth = req.headers.get("authorization");
  return auth === `Bearer ${secret}`;
}

export async function GET(req) {
  if (!isAuthorized(req)) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    // 1. Read current rotation state from GitHub (source of truth).
    const statePath = "content/state.json";
    const stateFile = await getFile(statePath);
    const state = stateFile
      ? JSON.parse(stateFile.content)
      : { topicIndex: 0, dispatch: 0 };

    const topics = siteConfig.topics;
    const topic = topics[state.topicIndex % topics.length];
    const dispatch = state.dispatch + 1;

    // 2. Generate the post (free template, or Gemini if GEMINI_API_KEY is set).
    const { title, dek, body } = await generatePost(topic, dispatch);

    // 3. Build the markdown file with frontmatter.
    const date = new Date().toISOString().slice(0, 10);
    const slug = `${date}-${slugify(title)}`;
    const frontmatter = [
      "---",
      `title: ${JSON.stringify(title)}`,
      `date: ${JSON.stringify(date)}`,
      `dispatch: ${dispatch}`,
      `topic: ${JSON.stringify(topic)}`,
      `dek: ${JSON.stringify(dek)}`,
      "---",
      ""
    ].join("\n");

    const postPath = `content/posts/${slug}.md`;
    await putFile(postPath, frontmatter + body, `Dispatch #${dispatch}: ${title}`);

    // 4. Advance and save rotation state.
    const newState = {
      topicIndex: state.topicIndex + 1,
      dispatch
    };
    await putFile(
      statePath,
      JSON.stringify(newState, null, 2),
      `Advance state to dispatch #${dispatch}`,
      stateFile?.sha
    );

    return Response.json({ ok: true, slug, title, dispatch, topic });
  } catch (err) {
    console.error(err);
    return Response.json({ error: err.message }, { status: 500 });
  }
}
